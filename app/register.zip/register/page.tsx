"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import axios from "axios";

export default function RegisterPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    userName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const { name, value } = e.target;
    setFormData((prev: FormData) => ({ ...prev, [name]: value }));
  };

  interface FormData {
    userName: string;
    email: string;
    password: string;
    confirmPassword: string;
  }

  interface AxiosErrorResponse {
    response?: {
      data?: {
        message?: string;
      };
    };
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");

    if (!formData.userName || !formData.email || !formData.password) {
      setError("All fields are required");
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    try {
      setLoading(true);
      const response = await axios.post("http://localhost:5000/admin/register", {
        userName: formData.userName,
        email: formData.email,
        password: formData.password,
      });

      if (response.data) {
        router.push("/login?registered=true");
      }
    } catch (error) {
      setError((error as AxiosErrorResponse).response?.data?.message || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>  
        <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-xl shadow-lg">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-[#224295]">Create an Admin Account</h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Or <Link href="/login" className="font-medium text-[#224295] hover:text-blue-700">sign in to your account</Link>
          </p>
        </div>

        {error && <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4 text-red-700">{error}</div>}

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
            {[
              { id: "userName", label: "Username", type: "text", autoComplete: "username" },
              { id: "email", label: "Email address", type: "email", autoComplete: "email" },
              { id: "password", label: "Password", type: "password", autoComplete: "new-password" },
              { id: "confirmPassword", label: "Confirm Password", type: "password", autoComplete: "new-password" },
            ].map(({ id, label, type, autoComplete }) => (
              <div key={id}>
                <label htmlFor={id} className="block text-sm font-medium text-gray-700">{label}</label>
                <input
                  id={id}
                  name={id}
                  type={type}
                  autoComplete={autoComplete}
                  required
                  className="w-full px-3 py-2 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder={label}
                  value={formData[id]}
                  onChange={handleChange}
                />
              </div>
            ))}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-[#224295] hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300"
          >
            {loading ? "Registering..." : "Register"}
          </button>
        </form>
      </div>
    </div>
    
    </>
    
  );
}
